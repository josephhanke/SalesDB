﻿SELECT 
	RepLastname AS SalesRep, 
	SUM([Transaction].UnitsSold*Item.ItemCost) AS Earnings
	FROM SalesRep

JOIN [Transaction]
	ON SalesRep.RepID = [Transaction].RepID

JOIN  Item
	ON Item.ItemID = [Transaction].ItemID

GROUP BY RepLastname;